#include <stdio.h>

int main()
{
	printf("This is a test!\n");
	printf("Oh no, I encountered an error!\n");
	return 1;
}